<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  height: 700px;
  }
  div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
 background-color:black;
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
div#content{
          width: 100%;
		  margin-top: -50px;
		  height:400px;
		  background-image: url(imagesCAP44Q2U.jpg);}
div#form{
           width: 30%;
		 text-align: left;
		  height:150px;
		  padding: 20px;
		  color: olive;
		  background-color:white;}


 
</style>
</head>
<body>
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>

<br>
<!--Navigation-->

<ul id="navList">



</ul>
<br><br><br><br>
<div id="content">
<br><br><br><br>
<div id="form">
<center>
<i><b>Please Enter Your Username and Password to login </b></i></center>
<center><img src="imagesavator.png"width="100" height="80">
</center>
<p>Username <input type="text" name="username" value="" size="20" maxlength=""35></p>
 <p>password <input type="text" name="upassword" value="" size="20" maxlength=""35></p>
<center> <input type="submit" name="submit" value="Submit"></center>
<center><br>
 <i><b>Click On The Link Bellow To Create A New Account </b></i>
<br><a href="CreateAccount.php">Create New Account</a></center>
</div>
<br>
</div>
<br>
</div>
</div>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</body>
</html>