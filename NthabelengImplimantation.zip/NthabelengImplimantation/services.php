<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  height: 700px;
  }
  div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
div#article {
           width:310px;
		   height:530px;
		   float: left;
		   text-align: left;
           color: white;
		   margin-left: -10px;
		   padding: 20px;
		   margin-top: -55px;
           letter-spacing: 1px;
		   background-image: url(imagesCAP44Q2U.jpg);}
div#sidebar {
		   float: right;
           width:310px;
		   height:530px;
		   text-align: left;
           color: white;
		   margin-top: -55px;
		   padding: 20px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   }
div#middle {
		   float: center;
           width:380px;
		   height:530px;
		   text-align: left;
           color: white;
		   margin-top: -55px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   }
 div#middle a{text-decoration: none;
 }
 
 div#article a{margin-right: 5px;
	  background-color: white;
	  padding:5px 10px 5px 10px;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
 
 div#email{background-color: white;
           width: 200;
		   height: 50;
		   padding: 10px;
		   color: olive;}
		   
</style>
</head>
<body>
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>

<br>
<!--Navigation-->

<ul id="navList">

<li><a href="home.php">Home</a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="services.php"><b>Services</b></a></li>
<li><a href="special.php">Specials</a></li>
<li><a href="contacts_us.php">Contact Us</a></li>
<li><a href="special.php">LogIn</a></li>
<li><a href="contacts_us.php">SignUp</a></li>

</ul>
<br><br><br><br>
<div id="article">
<h3><i>Our Room Profile Includes:</i></h3>
-22 Starndard Rooms<br>
-10 Tween Rooms <br>
-9 Single Rooms<br>
-7 Exacutive rooms<br>
-4 Self Catering<br>
- All Newly refunished And A Suite Barthroom
<h3><i>Our Room Profile Includes:</i></h3>
-Telephone<br>
-Mini Bar Fridge<br>
-Free Wifi In All Rooms<br>
-Air-cons<br>
-Tea And Coffee Facilities
<br><br>
<br>
<center>
<a href="gghjvjbmv"><b>Online booking</b></a>
</center>

</div>
<div id="sidebar">
<center><h3><i><b>About Us...</b></i></h3>
 <b>Email us on: </b><br>infor@traveller.com 
 <br><br>
 <b>Call us on:</b><br> (012)-799-5172<br> <br> 
 <b>Write To Us On: </b><br>Lucas Mangope Drive,<br> Mabopane,<br> 0190</center>
 
 <br><br>
 <div id="email">
 <i>Please signup For our online newslatter to stay up to date with our special here at Traveller's Hotel </i>
 <p><input type="text" name="username" value="" size="20" maxlength=""35><input type="submit" name="submit" value="Submit"></p>
 </div>
</div>
<div id="middle">
<h3><i>Take A Look At Our Rooms...</i></h3>
<center>
<img src="imagesCA75LE8M.jpg"width="120" height="100">
<img src="imagesCABAJPA3.jpg"width="120" height="100">
<img src="images1.jpg"width="120" height="100">
</center>
<a href="jjjjjj"><i><b>Starndard Rooms</b></i></a></li>
<br>
<center>
<img src="imagesCA75LE8M.jpg"width="120" height="100">
<img src="imagesCABAJPA3.jpg"width="120" height="100">
<img src="images1.jpg"width="120" height="100">
</center>
<a href="jjjjjj"><i><b>Tween Roomss</b></i></a></li>
<br>
<center>
<img src="imagesCA75LE8M.jpg"width="120" height="100">
<img src="imagesCABAJPA3.jpg"width="120" height="100">
<img src="images1.jpg"width="120" height="100">
</center>
<a href="jjjjjj"><i><b>Single Rooms</b></i></a></li>
<br>
<center>
<img src="imagesCA75LE8M.jpg"width="120" height="100">
<img src="imagesCABAJPA3.jpg"width="120" height="100">
<img src="images1.jpg"width="120" height="100">
</center>
<a href="jjjjjj"><i><b>Exacutive rooms</b></i></a></li>
</div>
<br>
<br>
<br>

</div></center>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</body>
</html>