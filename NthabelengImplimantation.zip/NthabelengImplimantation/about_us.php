<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  
  height:400px;
  }
 div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
 background-color:black;
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
	

div#article {
           width:740px;
		   height:200px;
		   float: left;
		   text-align: left;
           color: white;
		   margin-left: -10px;
		   padding: 20px;
		   margin-top: -55px;
           letter-spacing: 1px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   }
div#sidebar {
		   float: right;
           width:260px;
		   height:200px;
           color: white;
		   margin-top: -55px;
		   padding-left: 10px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   }
		   
div#bottom {
			width: 101%;
			height: 50px;
			margin-top:30px;
		   color: olive;
		    background-image: url(imagesCAP44Q2U.jpg);
		   }


/* mouse over link */
ul#navList a:hover {
    color: red;
}

</style>
</head>
<body>
<!--header-->

<br>
<!--Navigation-->
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>
<br>
<ul id="navList">
<center>
<li><a href="home.php">Home</a></li>
<li><a href="about_us.php"><b>About Us</b></a></li> 
<li><a href="rooms.php">Rooms</a></li>
<li><a href="events.php">Conferences & Events</a></li>
<li><a href="login.php">Onlne_Bpooking</a></li>
<li><a href="Contact_Us.php">Contact Us</a></li>
<li><a href="login.php">LogIn</a></li>
<li><a href="signup.php">SignUp</a></li>
</center>
</ul>
<br>
<br>
<!--End Navigation--->


<br>

<div id="article">
<h3 ><i><b>About Us...</b></i></h3>
 Traveller's plek is a newly launched township hotel situated in the heart of Mabopane, north of Pretoria.
 The hotel is conveniently located close to Morula Sun Casino, Morula Shopping Centre, Lehae Private Hospital, 
 and Odi sport-field Stadium. Traveller's plek hotel specialises in both leisure and Business accommodation services,
 providing a warm African accommodation mixed with modern lifestyle trends. The hotel offers a wide range of rooms to
 meet the traveller's requirements, conference facilities & equipment and boardroom facilities.
</div>

<div id="sidebar">
<center><h3><i><b>Contact Us...</b></i></h3>
 <b>Email us on: </b><br>infor@traveller.com 
 <br><br>
 <b>Call us on:</b><br> (012)-799-5172<br> <br> 
 <b>Write To Us On: </b><br>Lucas Mangope Drive,<br> Mabopane,<br> 0190</center>
</div>



<div id="bottom">
<br>
<marquee style="height:70;width:600" scrollamount="100" scrolldelay="1300" direction="">
<h2>Enjoy A ***** '5' Service In A Township Setting !!</h2>
</marquee>
<br>
<br>
</div>

<br><br>
Copyright Reserved. Created by NM.Ratona 49282093 &copy;
</div></center>

</body>
</html>