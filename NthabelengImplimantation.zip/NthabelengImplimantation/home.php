<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  float: center;
  height:700px;
  }
div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
		  
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
	 
	  ul#navList a{
	  background-color:black;
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
	
div#content {
 background-image: url(imagesCAP44Q2U.jpg);
		   height:100px;
           width: 100%;
		   padding: 2px;
		   font-family: geogia, serif;
		   color: olive;
		   
		   }
		   
div#bottom {
			width: 101%;
			height: 50px;
		   color: olive;
		    background-image: url(imagesCAP44Q2U.jpg);
		   }




/* mouse over link */
ul#navList a:hover {
    color: red;
}


</style>
</head>
<body>
<!--header-->
<center>
<div id="container">
<center>
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>

</div>
</center>
<br>
<!--Navigation-->
<center>
<ul id="navList">

<li><a href="home.php"><b>Home</b></a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="rooms.php">Rooms</a></li>
<li><a href="events.php">Conferences & Events</a></li>
<li><a href="login.php">Onlne_Bpooking</a></li>
<li><a href="Contact_Us.php">Contact Us</a></li>
<li><a href="login.php">LogIn</a></li>
<li><a href="signup.php">SignUp</a></li>
</ul>
</center>

<!--End Navigation--->
<!--body image-->

<div id="content">

<center>
<b><h1>Welcome To Traveller's Plek Hotel </h1></b></center>


<br>
<marquee style="height:100;width:500" scrollamount="100" scrolldelay="1300" direction="right">

<img src="images2.jpg"width="150" height="120"><img src="images1.jpg"  width="150" height="120"><img src="images4.jpg" width="150" height="120">
<img src="images5.jpg"width="150" height="120"><img src="images6.jpg" width="150" height="120">
<img src="images7.jpg"  width="150" height="120"></marquee>

<center><i><h2>Facilities</h2></i></center>
<img src="coprorate.png"width="20" height="20"><b>CONFERENCE</b><img src="laundry.png"width="20" height="20"><b>LAUNDRY SERVICES</b>
<img src="resturant.png"width="20" height="20"><b>RESTURANTS</b><img src="wifi.png"width="20" height="20"><b>FREE WIFI</b>
<img src="bar.png"width="20" height="20"><b>BAR</b> and more...
</div>

<br>
<div id="bottom">
<b>Email us on : </b>infor@traveller.com 
 <br><br>
 <b>Call us on :</b> (012)-799-5172<br> <br> 
 <b>Write To Us On : </b>Lucas Mangope Drive, Mabopane, 0190
 </div>
 <br> <br> <br>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>

</div>

</body>

</html>