<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  height: 700px;
  }
  div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
 background-color:black;
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
div#content{
          width: 100%;
		  margin-top: -50px;
		  height:400px;
		  background-image: url(imagesCAP44Q2U.jpg);}
div#article {
           width:400px;
		   height:200px;
		   float: left;
		   text-align: right;
           color: white;
		   margin-left: -10px;
		   padding: 20px;
		   margin-top: -55px;
           letter-spacing: 1px;
		   }
div#sidebar {
           
		   float: left;
           width:600px;
		   height:400px;
		   text-align: left;
           color: white;
		   margin-top: -55px;
		   padding: 40px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		  
		   }
 div#sidebar i{color: olive}
	/* visited link */
ul#navList a:visited {
    color: blue;
}



/* mouse over link */
ul#navList a:hover {
    color: red;
}
</style>
</head>
<body>
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>

<br>
<!--Navigation-->

<ul id="navList">

<li><a href="home.php">Home</a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="rooms.php">Rooms</a></li>
<li><a href="events.php">Conferences & Events</a></li>
<li><a href="login.php">Onlne_Bpooking</a></li>
<li><a href="Contact_Us.php"><b>Contact Us</b></a></li>
<li><a href="login.php">LogIn</a></li>
<li><a href="signup.php">SignUp</a></li>

</ul>
<br><br><br><br>
<div id="content">
 <br><br><br>
<div id="sidebar">

 <br><br><br>
 <i>We would like to hear from you! contact us on any of address provided below and we will get back to you as soon as possible  </i>
 <p>Alternatively you can complete our form</p>
<br><br>
 <p>Name <input type="text" name="username" value="" size="15" maxlength=""35></p>
 <p>E-mail <input type="text" name="username" value="" size="30" maxlength=""35></p>
 <p>Phone <input type="text" name="username" value="" size="30" maxlength=""35></p>
 <p>
 <textarea name="message" rows="7" cols="30">
 Enter your message here...
 </textarea>
 </p>
  <input type="submit" name="submit" value="Submit">
  <input type="submit" name="submit" value="Clear"></p></div>
 
 <br><br><br>

<div id="article">
 <br><br><br>
<center>

<center><h3><i><b>Contact Us...</b></i></h3>
 <b>Email us on: </b><br>infor@traveller.com 
 <br><br>
  <br><br>
 <b>Call us on:</b><br> (012)-799-5172<br> <br>
 <br><br> 
 <b>Write To Us On: </b><br>Lucas Mangope Drive,<br> Mabopane,<br> 0190</center>
 

</div>
<br>
<br>
</div>
</div>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</body>
</html>