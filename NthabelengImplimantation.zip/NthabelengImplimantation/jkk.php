<html>
<head>
<title></title>
<!--stylesheet--link-->
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--header-->
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>

</div>
<br>
<!--Navigation-->

<ul id="navList">
<center>
<li><a href="home.php">Home</a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="services.php">Services</a></li>
<li><a href="special.php"><b>Specials</b></a></li>
<li><a href="contacts_us.php">Contact Us</a></li>
<li><a href="special.php">LogIn</a></li>
<li><a href="contacts_us.php">SignUp</a></li>
</center>
</ul>
<br>
<br>
<!--End Navigation--->


<div id="article">

<center>
<b><h1>Traveller's Plek Hotel </h1></b></center>
<br>
<br>
<br>

</div>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</body>
</html>