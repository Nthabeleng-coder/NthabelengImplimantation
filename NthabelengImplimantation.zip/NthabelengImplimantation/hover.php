<!DOCTYPE html>
<html>
<head>
<style>
/* unvisited link */
a:link {
    color: green;
}

/* visited link */
a:visited {
    color: green;
}

/* mouse over link */
a:hover {
    color: red;
}

/* selected link */
a:active {
    color: yellow;
} 
</style>
</head>
<body>

<p>Mouse over and click the link: <a href="hover.php">w3schools.com</a></p>

</body>
</html>
