<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  height: 400px;
  }
  div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
	  color: blue;
	  background-color:black;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
div#content{
          width: 100%;
		  margin-top: -50px;
		  height:200px;
		  background-image: url(imagesCAP44Q2U.jpg);}
div#article {
           width:350px;
		   height:400px;
		   float: left;
		   text-align: left;
           color: white;
		   margin-left: -10px;
		   padding: 30px;
		   margin-top: -55px;
           letter-spacing: 1px;
		   }
div#sidebar {
           border-left:solid thin olive;
		   float: right;
           width:380px;
		   height:400px;
		   text-align: left;
           color: white;
		   margin-top: -55px;
		   padding: 30px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		  
		   }
div#middle {
		   float: center;
           width:260px;
		   padding: 10px;
		   height:400px;
		   text-align: left;
           color: white;
		   margin-top: -55px;
		   margin-right: -10px;
		   letter-spacing: 1px;
		   
		   }
 div#middle a{text-decoration: none;
 }
 div#sidebar i{color: olive}
 
div#article a{margin-right: 5px;
	  background-color: white;
	  padding:5px 10px 5px 10px;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
	/* visited link */
ul#navList a:visited {
    color: blue;
}			


/* mouse over link */
ul#navList a:hover {
    color: red;
}
div#article a:hover{
            color: red; }
div#middle a:hover{
            color: red; }

</style>
</head>
<body>
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>

<br>
<!--Navigation-->

<ul id="navList">

<li><a href="home.php">Home</a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="rooms.php">Rooms</a></li>
<li><a href="events.php"><b>Conferences & Events</b></a></li>
<li><a href="login.php">Onlne_Bpooking</a></li>
<li><a href="Contact_Us.php">Contact Us</a></li>
<li><a href="login.php">LogIn</a></li>>
<li><a href="signup.php">SignUp</a></li>

</ul>
<br><br><br><br>
<div id="content">
<div id="article">
<center>
<h3><i>Conferences & Events </i></h3>
<i>Our affordable package and options included catering for any function or event, 
be it business or private. Just inform us on your plan and ideas and we will take care of the rest</i>
</center>
<br>
<h5><i>We Specialize in:</i></h5>
* Year-end Functions<br>
*Corporate Functions <br>
*Weddings<br>
*Birthday Parties<br>
*Bachelorattes/Bridal shower  <br>
*Baby shower<br>
*Food Platter For Parties or Business Functions
<br>
<center>
<br><br>
<a href="login.php"><b>Online booking</b></a>
</center>
</div>
<div id="sidebar">

 <br><br><br>
 <i>for more information please contact us </i>
<br><br>
 <p>Name <input type="text" name="username" value="" size="20" maxlength=""35></p>
 <p>E-mail <input type="text" name="username" value="" size="20" maxlength=""35></p>
 <p>Phone <input type="text" name="username" value="" size="20" maxlength=""35></p>
 <p>
 <textarea name="message" rows="7" cols="30">
 Enter your message here...
 </textarea>
 </p>
  <input type="submit" name="submit" value="Submit"></p>
 
</div>
<div id="middle">
<br><br><br><br><br><br><br>
<center>
<a href="jjjjjj"><i><b>Year-end Function</b></i></a><br>
<img src="imagesCABVW1AU.jpg"width="70" height="60">
<img src="imagesCAQBDIEP.jpg"width="70" height="60">
<img src="images6.jpg"width="70" height="60"><br>
</center>
<br>
<center>
<a href="jjjjjj"><i><b>Corporate Functions</b></i></a><br>

<img src="images7.jpg"width="70" height="60">
<img src="imagesCA79D07Q.jpg"width="70" height="60">
<img src="images2.jpg"width="70" height="60">
</center>
<br>
<center>
<a href="jjjjjj"><i><b>Weddings & Birthday Parties</b></i></a><br>

<img src="imagesCAE5UYJE.jpg"width="70" height="60">
<img src="imagesCANSQTRN.jpg"width="70" height="60">
<img src="imagesCAVS4C51.jpg"width="70" height="60">
</center>
<br>

</div>
<br>
<br>
<br>
</div>
</div>
<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</body>
</html>