<html>
<head>
<title></title>
<!--stylesheet--link-->
<style type="text/css">
body { 
    background-image: url(untitled3.png);
    }
div#container{
  width: 1000;
  height: 700px;
  }
  div#header {
           width: 103%;
		   height: 60px;
		   background-image: url(imagesCAP44Q2U.jpg);
		   margin: -10px;
		   }
h1.head, h3.subhead{
                   font-family: geogia, serif;
				   margin-left: 20px;
				   color: olive;
				   }
h1.head{
       font-size: 2.25em;
	   padding-top: 7px;
	   margin-top: 10px;
	   }
h3.subhead{
          margin-top: -20px;
		  letter-spacing: 1px;
		  padding-left: 10px;
		  }
ul#navList {
    padding: 0;
	margin: 0;
	list-style-type: none;
	display: inline;}
	ul#navList li{
	 display: inline;}
 ul#navList a{
 background-color:black;
	  color: blue;
	  margin-right: 5px;
	  padding:5px 10px 5px 10px;
	  text-decoration: none;
	  box-shadow: 5px 5px 4px #000;
	border-radius: 5px;
	-moz-border-radius:5px;}
div#content{
          width: 100%;
		  margin-top: -50px;
		  height:400px;
		  background-image: url(imagesCAP44Q2U.jpg);}


div#form {
    width: 450px;
    margin: 0 auto;
    padding: 15px;
	color: olive;
    background: white;
    border: 2px solid olive;
}
 label {
    width: 10em;
    padding-right: 1em;
    float: left;
}
#data input {
    float: left;
    width: 15em;
    margin-bottom: .5em;
}
#buttons input {
    float: left;
    margin-bottom: .5em;
}



/* mouse over link */
ul#navList a:hover {
    color: red;
}
</style>
</head>
<body>
<center>
<div id="container">
<div id="header">
<i>
<h1 class="head">
Traveller's
</h1 >
<h3 class="subhead">
Plek Hotel
</h3>
</i>
</div>

<br>
<!--Navigation-->

<ul id="navList">

<li><a href="home.php">Home</a></li>
<li><a href="about_us.php">About Us</a></li> 
<li><a href="rooms.php">Rooms</a></li>
<li><a href="events.php">Conferences & Events</a></li><li>
<li><a href="login.php""><b>Onlne_Bpooking</b></a></li>
<li><a href="Contact_Us.php">Contact Us</a></li>
<li><a href="login.php">LogIn</a></li>
<li><a href="signup.php">SignUp</a></li>

</ul>
<br><br><br><br>
<div id="content">
<br>
<div id="form">
<form method="post" action="">
 <center>
<i><b>Please Fill In The Form Bellow To Create A New Account</b></i>
</center>
 <p><label for="name">Name :</label>
 <input type="text" name="name" value="" size="15" maxlength=""35>
</p>
 <p>
 <label for="surname">Surnaame :</label>
 <input type="text" name="surname" value="" size="15" maxlength=""35>
 </p>
 <p>
 <label for="company">Company name :</label>
 <input type="text" name="surname" value="" size="15" maxlength=""35>
 </p>
 
<p><label for="email">E-mail :</label>
<input type="text" name="email" value="" size="15" maxlength=""35>
</p>

<p><label fro="phone">Phone :</label> 
<input type="text" name="phone" value="" size="15" maxlength=""35>
</p>

 <p><label for="username">Username :</label>
 <input type="text" name="checkin" value="" size="15" maxlength=""35>
 </p>
 <p><label for="password">Password :</label>
 <input type="text" name="checkout" value="" size="15" maxlength=""35>
 </p>
 
<p><input type="submit" name="submit" value="Submit">
  <input type="submit" name="submit" value="Clear"></p>
  </form>
 
  </div>

<br>
</div>

<center>Copyright Reserved. Created by NM.Ratona 49282093 &copy;</center>
</div>
</body>
</html>